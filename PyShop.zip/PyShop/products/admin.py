from django.contrib import admin
from .models import Product, Upcoming, Order, Order2, Order1

class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'stock', 'image_url')

class UpcomingAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'code', 'image_url')

class OrderAdmin(admin.ModelAdmin):
    list_display = ('product_code', 'quantity', 'contact_no', 'address')

class Order1Admin(admin.ModelAdmin):
    list_display = ('product_code', 'quantity', 'name', 'bkash_no', 'contact_no', 'address')

class Order2Admin(admin.ModelAdmin):
    list_display = ('product_code', 'quantity', 'name', 'card_number', 'month', 'year', 'csv', 'address')

admin.site.register(Product, ProductAdmin)
admin.site.register(Upcoming, UpcomingAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(Order2, Order2Admin)
admin.site.register(Order1, Order1Admin)
