from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=255)
    price = models.FloatField()
    stock = models.IntegerField()
    image_url = models.CharField(max_length=3083)


class Upcoming(models.Model):
    name = models.CharField(max_length=255)
    price = models.FloatField()
    code = models.CharField(max_length=25)
    image_url = models.CharField(max_length=3083)

class Order(models.Model):
    product_code = models.CharField(max_length=10)
    quantity = models.IntegerField()
    contact_no = models.FloatField()
    address = models.CharField(max_length=250)

class Order2(models.Model):
    product_code = models.CharField(max_length=10)
    quantity = models.IntegerField()
    name = models.CharField(max_length=250)
    card_number = models.CharField(max_length=250)
    month = models.CharField(max_length=5)
    year = models.CharField(max_length=5)
    csv = models.CharField(max_length=25)
    address = models.CharField(max_length=250)


class Order1(models.Model):
        product_code = models.CharField(max_length=10)
        quantity = models.IntegerField()
        name = models.CharField(max_length=250)
        bkash_no = models.CharField(max_length=250)
        contact_no = models.CharField(max_length=250)
        address = models.CharField(max_length=250)