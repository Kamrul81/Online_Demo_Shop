from django.contrib import admin
from django.urls import path, include
from . import views


urlpatterns = (
    path('', views.index),
    path('new', views.new),
    path('buy', views.buy),
    path('home', views.home),
    path('processing', views.process),
    path('processing2', views.processing2),
    path('test', views.test),
    path('orderway', views.orderway),

)