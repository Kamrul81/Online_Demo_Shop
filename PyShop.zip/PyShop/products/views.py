from django.http import HttpResponse
from django.shortcuts import render
from .models import Product
from .models import Upcoming

def index(request):
    products = Product.objects.all()
    return render(request, 'index.html', {'products': products})

def new(request):
    products = Upcoming.objects.all()
    return render(request, 'new.html', {'products': products})

def buy(request):
        return render(request, 'buy.html')

def process(request):
    return render(request, 'process.html')

def processing2(request):
    return render(request, 'processing2.html')

def home(request):
    return render(request, 'home.html')

def test(request):
    return render(request, 'test.html')

def orderway(request):
    return render(request, 'orderway.html')